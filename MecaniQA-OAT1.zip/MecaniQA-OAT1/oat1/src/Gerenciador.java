package oat1.src;

public class Gerenciador {
    private static int proximoCodigoPeca = 1;
    private static int proximoCodigoServico = 1;

    public static int inserirPeca(Peca[] pecas, int totalPecas, Peca novaPeca) {
        if (novaPeca == null || totalPecas < 0 || totalPecas >= pecas.length) {
            return totalPecas;
        }
        novaPeca.codigo = proximoCodigoPeca++;
        pecas[totalPecas] = novaPeca;
        return totalPecas + 1;
    }

    public static int buscarPecaPorCodigo(Peca[] pecas, int totalPecas, int codigo) {
        for (int i = 0; i < totalPecas; i++) {
            if (pecas[i].codigo == codigo) {
                return i;
            }
        }
        return -1;
    }

    public static void listarPecas(Peca[] pecas, int totalPecas) {
        System.out.println("\nPECAS CADASTRADAS");
        for (int i = 0; i < totalPecas; i++) {
            Peca peca = pecas[i];
            System.out.printf("%d | %s | %s | venda R$ %.2f | estoque %d%n",
                    peca.codigo, peca.nome, peca.fabricante,
                    peca.precoVenda, peca.quantidadeEstoque);
        }
    }

    public static boolean atualizarPeca(Peca[] pecas, int totalPecas, int codigo,
            String nome, String fabricante, double precoCusto,
            double precoVenda, int quantidadeEstoque) {
        int indice = buscarPecaPorCodigo(pecas, totalPecas, codigo);
        if (indice == -1) {
            return false;
        }
        Peca peca = pecas[indice];
        peca.nome = nome;
        peca.fabricante = fabricante;
        peca.precoCusto = precoCusto;
        peca.precoVenda = precoVenda;
        peca.quantidadeEstoque = quantidadeEstoque;
        return true;
    }

    public static int removerPeca(Peca[] pecas, int totalPecas, int codigo) {
        int indice = buscarPecaPorCodigo(pecas, totalPecas, codigo);
        if (indice == -1) {
            return totalPecas;
        }
        for (int i = indice; i < totalPecas - 1; i++) {
            pecas[i] = pecas[i + 1];
        }
        pecas[totalPecas - 1] = null;
        return totalPecas - 1;
    }

    public static int inserirServico(Servico[] servicos, int totalServicos, Servico novoServico) {
        if (novoServico == null || totalServicos < 0 || totalServicos >= servicos.length) {
            return totalServicos;
        }
        novoServico.codigo = proximoCodigoServico++;
        servicos[totalServicos] = novoServico;
        return totalServicos + 1;
    }

    public static int buscarServicoPorCodigo(Servico[] servicos, int totalServicos, int codigo) {
        for (int i = 0; i < totalServicos; i++) {
            if (servicos[i].codigo == codigo) {
                return i;
            }
        }
        return -1;
    }

    public static void listarServicos(Servico[] servicos, int totalServicos) {
        System.out.println("\nSERVICOS CADASTRADOS");
        for (int i = 0; i < totalServicos; i++) {
            Servico servico = servicos[i];
            System.out.printf("%d | %s | %d min | R$ %.2f%n",
                    servico.codigo, servico.descricao,
                    servico.tempoEstimadoMinutos, servico.valorMaoDeObra);
        }
    }

    public static boolean atualizarServico(Servico[] servicos, int totalServicos, int codigo,
            String descricao, int tempoEstimadoMinutos, double valorMaoDeObra) {
        int indice = buscarServicoPorCodigo(servicos, totalServicos, codigo);
        if (indice == -1) {
            return false;
        }
        Servico servico = servicos[indice];
        servico.descricao = descricao;
        servico.tempoEstimadoMinutos = tempoEstimadoMinutos;
        servico.valorMaoDeObra = valorMaoDeObra;
        return true;
    }

    public static int removerServico(Servico[] servicos, int totalServicos, int codigo) {
        int indice = buscarServicoPorCodigo(servicos, totalServicos, codigo);
        if (indice == -1) {
            return totalServicos;
        }
        for (int i = indice; i < totalServicos - 1; i++) {
            servicos[i] = servicos[i + 1];
        }
        servicos[totalServicos - 1] = null;
        return totalServicos - 1;
    }
}

