package oat1.src;

public class Main {
    public static void main(String[] args) {
        Peca[] pecas = new Peca[100];
        Servico[] servicos = new Servico[50];
        int totalPecas = 0;
        int totalServicos = 0;

        Peca filtro = novaPeca("Filtro de oleo", "Bosch", 20.00, 35.90, 10);
        Peca pastilha = novaPeca("Pastilha de freio", "Fras-le", 65.00, 99.90, 8);
        totalPecas = Gerenciador.inserirPeca(pecas, totalPecas, filtro);
        totalPecas = Gerenciador.inserirPeca(pecas, totalPecas, pastilha);
        Gerenciador.atualizarPeca(pecas, totalPecas, filtro.codigo,
                "Filtro de oleo premium", "Bosch", 22.00, 39.90, 12);
        Gerenciador.listarPecas(pecas, totalPecas);

        Servico trocaOleo = novoServico("Troca de oleo", 40, 80.00);
        Servico alinhamento = novoServico("Alinhamento", 60, 120.00);
        totalServicos = Gerenciador.inserirServico(servicos, totalServicos, trocaOleo);
        totalServicos = Gerenciador.inserirServico(servicos, totalServicos, alinhamento);
        Gerenciador.atualizarServico(servicos, totalServicos, alinhamento.codigo,
                "Alinhamento e balanceamento", 75, 150.00);
        Gerenciador.listarServicos(servicos, totalServicos);

        System.out.println("\nIndice da peca 2: "
                + Gerenciador.buscarPecaPorCodigo(pecas, totalPecas, 2));
        totalPecas = Gerenciador.removerPeca(pecas, totalPecas, filtro.codigo);
        totalServicos = Gerenciador.removerServico(servicos, totalServicos, trocaOleo.codigo);
        System.out.println("Totais apos remocao: " + totalPecas + " peca(s), "
                + totalServicos + " servico(s)");
        Gerenciador.listarPecas(pecas, totalPecas);
        Gerenciador.listarServicos(servicos, totalServicos);
    }

    private static Peca novaPeca(String nome, String fabricante, double custo,
            double venda, int estoque) {
        Peca peca = new Peca();
        peca.nome = nome;
        peca.fabricante = fabricante;
        peca.precoCusto = custo;
        peca.precoVenda = venda;
        peca.quantidadeEstoque = estoque;
        return peca;
    }

    private static Servico novoServico(String descricao, int minutos, double valor) {
        Servico servico = new Servico();
        servico.descricao = descricao;
        servico.tempoEstimadoMinutos = minutos;
        servico.valorMaoDeObra = valor;
        return servico;
    }
}

