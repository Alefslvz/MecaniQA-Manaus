package oat1.src;

public class Servico {
    int codigo;
    String descricao;
    int tempoEstimadoMinutos;
    double valorMaoDeObra;
}

