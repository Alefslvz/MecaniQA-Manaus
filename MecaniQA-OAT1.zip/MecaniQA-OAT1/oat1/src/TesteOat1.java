package oat1.src;

public class TesteOat1 {
    public static void main(String[] args) {
        Peca[] pecas = new Peca[2];
        int total = 0;
        Peca primeira = new Peca();
        primeira.nome = "A";
        Peca segunda = new Peca();
        segunda.nome = "B";

        total = Gerenciador.inserirPeca(pecas, total, primeira);
        total = Gerenciador.inserirPeca(pecas, total, segunda);
        exigir(total == 2, "insercao");
        exigir(primeira.codigo != segunda.codigo, "codigo sequencial e unico");
        exigir(Gerenciador.buscarPecaPorCodigo(pecas, total, segunda.codigo) == 1, "busca");
        exigir(Gerenciador.atualizarPeca(pecas, total, segunda.codigo,
                "B2", "Fabricante", 1, 2, 3), "atualizacao");
        total = Gerenciador.removerPeca(pecas, total, primeira.codigo);
        exigir(total == 1 && pecas[0] == segunda && pecas[1] == null, "remocao reorganizada");
        System.out.println("OAT 1: todos os testes passaram.");
    }

    private static void exigir(boolean condicao, String cenario) {
        if (!condicao) {
            throw new AssertionError("Falha no cenario: " + cenario);
        }
    }
}

