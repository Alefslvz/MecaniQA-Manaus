package oat1.src;

public class Peca {
    int codigo;
    String nome;
    String fabricante;
    double precoCusto;
    double precoVenda;
    int quantidadeEstoque;
}

