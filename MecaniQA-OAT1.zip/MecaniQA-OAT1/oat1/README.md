# OAT 1 - Estruturas de Dados Estáticas

Primeira etapa do MecaniQA Manager, dedicada ao gerenciamento de peças e
serviços com arrays unidimensionais de tamanho fixo.

## Conteúdos aplicados

- Tipos Abstratos de Dados (TADs)
- Arrays estáticos
- Métodos estáticos
- Operações de inserção, listagem, atualização e remoção
- Busca linear por código
- Reorganização do array após uma remoção
- Códigos sequenciais gerados pelo sistema

## Arquivos

```text
oat1/
├── src/
│   ├── Gerenciador.java
│   ├── Main.java
│   ├── Peca.java
│   ├── Servico.java
│   └── TesteOat1.java
└── README.md
```

## Executar

A partir da raiz do projeto:

```bash
javac -d out oat1/src/*.java
java -cp out oat1.src.Main
```

## Testar

```bash
java -cp out oat1.src.TesteOat1
```

O teste verifica as principais operações de peças e serviços sem depender de
uma biblioteca externa de testes.
